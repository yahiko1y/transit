<?php session_start();
  ?>
<style>
.cent{ width:60%; margin-left:20%; margin-top:20px; background: rgba(243,190,138,1.00); color:rgba(32,12,116,1.00) ; font-size:1.5em;
border-radius: 20px; padding:20px; align-content:center;  }

input,td,button{ font-size:1.3em;}
td,button{ width:50%;}
 
</style>
<body>

<?php 

require("dbcon.php");
require("adnav.php");
 $err="";
if( isset($_POST['pwd'])){


 
  
$old =trim($_POST['old']);
$password =trim($_POST['password']);
$password_old =$_SESSION['password'] ;

if($old!=$password_old){ $err =" Incoreect old password <br>";}else{ $err = "";

mysqli_query($con," update admin set password ='$password' where id ='$adminid' limit 1 ");
 

  
echo'<script>
	alert("  Password has been changed , you will login again");
	window.location="admlogin.php";
	 
	</script>';
	
	 }
}

?>



<div class="cent">
 
 <form method="post" action="adminpw.php" enctype="multipart/form-data">
 <table>
 <tr><td colspan="2" align="center"> Welcome Dear  Adiministrator  !! Login below &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php"> << Back</a></td></tr>
  
   
 <tr>
   <td align="right">Old Password</td><td><label style="color:red; font-size:2em; "> <?php echo $err; ?></label><input  name="old" /></td>
 </tr>
 
 <tr>
   <td align="right"> New Password</td><td><input type="new" name="password" /></td>
 </tr>
 
 
 
 <tr>
   <td></td><td><br><br> <button type="submit" name="pwd"> Change Password</button></td>
 </tr>
 
 
 
 </table>
  </form>

</div>

</body>