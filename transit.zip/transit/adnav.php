 
<style>
td.rec{ border-bottom: solid 3px rgba(38,31,31,1.00)}
ul{ display:inline; list-style:none; align-content:center  }

ul li a{ text-decoration:none;}
li{ display:inline; float:left; margin-left:11px;  }
li a{ font-size:2em; background:rgba(107,106,244,1.00); color:rgba(5,5,5,1.00); border-radius:10px; padding:3px }
li:hover a{ background:rgba(9,24,82,1.00); color:rgba(252,252,252,1.00) !important; font-size:2em;}
 .nv{ width:100%; align-content:center; padding:20px; background:rgba(203,232,245,1.00); height:auto; padding-bottom:40px;}
</style>
 
 <div class="nv" align="center">
 <h1> ONLINE TRANSPORTATION SYSTEM " Admin Panel"</h1>
 <ul >
  
 <li><a href="adhome.php">Oders</a></li>
 <li><a href="search.php">Search Orders</a></li>
  
 <li><a href="adminpw.php">change password</a></li>
 <li><a href="index.php"><font color="#F13E41">logout <?php echo $_SESSION['adnames'] ;?></font> </a></li>
 
 </ul></div>
 
 
 <?php
 
   $adminid=  $_SESSION['adminid']*1  ;
  
  
  ?>