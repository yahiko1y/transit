
<style>
.cent{ width:60%; margin-left:20%; margin-top:20px; background:rgba(123,243,152,1.00); color:rgba(32,12,116,1.00) ; font-size:1.5em;
border-radius: 20px; padding:20px; align-content:center;  }

input,td,button{ font-size:1.3em;}
td,button{ width:50%;}
 
</style>
<body>

<?php 

require("dbcon.php");
if( isset($_POST['sendx'])){


$fulnames =$_POST['fulnames'];
$tel =$_POST['tel'];
$username =$_POST['username'];
$password =$_POST['password'];


$qr =" insert into clients (fulnames,tel,username,password) values('$fulnames','$tel','$username','$password')";


 mysqli_query($con,$qr) or die(" <a href='sss.pjp'>Sorry !! try again to regester</a>");
	
echo'<script>
	alert(" regesteration sucessful  you can login now");
	window.location="login.php";
	 
	</script>';
	
	 
}

?>



<div class="cent">
 
 <form method="post" action="reg.php" enctype="multipart/form-data">
 <table>
 <tr><td colspan="2" align="center"> fill in below to register  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php"> << Back</a></td></tr>
 <tr>
   <td align="right">fulnames</td><td><input name="fulnames" type="text"/></td>
 </tr>
 
 <tr>
   <td align="right">Telephone No</td><td> <input name="tel" /></td>
 </tr>
 
 <tr>
   <td align="right">username</td><td><input  name="username" /></td>
 </tr>
 
 <tr>
   <td align="right">Password</td><td><input type="password" name="password" /></td>
 </tr>
 
 
 
 <tr>
   <td></td><td><br><br> <button type="submit" name="sendx"> Save</button></td>
 </tr>
 
 <tr>
   <td></td><td></td>
 </tr>
 
 </table>
  </form>

</div>

</body>