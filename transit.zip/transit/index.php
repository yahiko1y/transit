
<style>
.cent{ width:60%; margin-left:20%; margin-top:20px; background:rgba(123,243,152,1.00); color:rgba(32,12,116,1.00) ; font-size:1.5em;
border-radius: 20px; padding:20px; align-content:center;  }
</style>
<body>

<div class="cent">

<p> transportation system By </p>
<P> MUNA MOHAMED ABDI  </p>
<p> REgNo &nbsp;:&nbsp;  20/579/BSCS-S</p>



<p><a href="login.php"> Client login</a> &nbsp;&nbsp;<a href="reg.php"> Regester</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

 <a href="admlogin.php"> Admin login</a></p>

</div>

</body>