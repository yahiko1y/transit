<?php session_start();

$iname ="";
$weight ="";
$bfrom ="";
$bto ="";
$date ="";
$updat="";
 ?>
<style>
 
 
</style>
<body>

<?php 

require("dbcon.php");
require("cnav.php");

 
 
if( isset($_POST['order'])){


$inamex =$_POST['iname'];
$weightx =$_POST['weight'];
$bfromx =$_POST['bfrom'];
$btox =$_POST['bto'];
$statusx = 'not delivered yet' ;
$datex =$_POST['date'];



$qr =" insert into orders (iname,weight,bfrom,bto,status,clientid,date)
 values('$inamex','$weightx','$bfromx','$btox','$statusx','$clientid','$datex')";


 mysqli_query($con,$qr) or die(" Oooops !!! Order failed , Try again");
	
echo'<script>
	alert(" Order sucessful  ");
	 
	</script>';
	
	 
}else if (isset($_POST['delx'])){
	
	$delx=$_POST['delx'];
	
	mysqli_query($con," delete from orders where id ='$delx' limit 1");
	echo'<script>	alert(" Record deleted fully ");	</script>';
	}
	
	else if (isset($_POST['updatbtn'])){
	
	$updat=$_POST['updatbtn'];
	
	 $qr =" select * from orders  where id ='$updat' limit 1";
$qrc =mysqli_query($con,$qr);

 $qrx=mysqli_fetch_assoc($qrc);
 
$iname =$qrx['iname'];
$weight =$qrx['weight'];
$bfrom =$qrx['bfrom'];
$bto =$qrx['bto'];
$date =$qrx['date'];
	} else if( isset($_POST['updata'])){

$updatau =$_POST['updata'];
$inameu =$_POST['iname'];
$weightu =$_POST['weight'];
$bfromu =$_POST['bfrom'];
$btou =$_POST['bto'];
 
$dateu =$_POST['date'];



$qr ="update orders set iname='$inameu',weight='$weightu',bfrom='$bfromu',bto='$btou',date='$dateu' where id='$updatau' limit 1 ";


 mysqli_query($con,$qr) or die(" Oooops !!! update failed , Try again".mysqli_error($con));
	
echo'<script>
	alert(" Update has been sucessful  ");
	 
	</script>';
	
	 
}
	
	
?>



<div class="cent">



 
 <form method="post" action="clienthome.php" enctype="multipart/form-data"
  >
 <table style="width:25%; float:left; background:rgba(204,248,249,1.00)">
 <tr><td colspan="2" align="center" >  Welcome Dear  Client  !! Login below </td></tr>
  
 <tr>
   <td align="right">Item name </td><td> <input name="iname"  value="<?php echo $iname ; ?>"/>&nbsp;&nbsp;</td></tr><tr>
   <td> Weight </td><td><input  name="weight" value="<?php echo $weight ; ?>" /></td></td></tr><tr>
   <td> location </td><td><input  name="bfrom" value="<?php echo $bfrom; ?>" /></td></td></tr><tr>
   <td> destination </td><td><input  name="bto" value="<?php echo $bto ; ?>" /></td></td></tr><tr>
   <td> date </td><td><input  name="date"  type="date" value="<?php echo $date ; ?>" /></td>
 </tr>
  
 
 <tr>
   <td></td><td><br><br> <button type="submit" name="<?php 
   if($updat==""){ echo 'order';}else{ echo 'updata';} ?>" value="<?php echo $updat; ?>"> <?php 
   if($updat==""){ echo 'order';}else{ echo 'Update';} ?></button></td>
 </tr>
 
 </table>
  </form>
  
  
  
  
  
  
  
  <table style="width:73%; margin-left:1%; float:left; background:rgba(188,244,247,1.00)">
  <tr><td align="center"> my orders </td></tr>
  
  <tr>
  <td></td>
  <td> item</td>
  <td> weight </td>
  <td> location</td>
  <td> destination</td>
  <td> date</td>
  <td> status</td>
  
  </tr>
  
  <?php 
  
  $qr =" select * from orders  where clientid ='$clientid' order by id desc";
$qrc =mysqli_query($con,$qr);

 while($qrx=mysqli_fetch_assoc($qrc)){ 
   ?>
   
   
     <tr>
  <td></td>
  <td> <?php echo $qrx['iname']; ?></td>
  <td> <?php echo $qrx['weight']; ?></td>
  <td> <?php echo $qrx['bfrom']; ?></td>
  <td> <?php echo $qrx['bto']; ?></td>
  <td> <?php echo $qrx['date']; ?></td>
  <td> <?php echo $qrx['status']; ?></td>
  <td> 
  <form method="post" action="clienthome.php" enctype="multipart/form-data" onSubmit='return confirm("do you want to Update") '>
  <button name="updatbtn" value="<?php echo $qrx['id']; ?>" >Edit</button></form></td>
  <td>
  <form method="post" action="clienthome.php" enctype="multipart/form-data" onSubmit='return confirm("do you want to delete") '>
  <button value="<?php echo $qrx['id']; ?>" name="delx" >Delete</button></form></td>
  
  </tr>
   
   
  
  <?php } ?>
  </table>

</div>

</body>