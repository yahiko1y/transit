<?php session_start();

$iname ="";
$weight ="";
$bfrom ="";
$bto ="";
$date ="";
$updat="";
 ?>
<style>
 
 
</style>
<body>

<?php 

require("dbcon.php");
require("adnav.php");

 
 
 if (isset($_POST['delx'])){
	
	$delx=$_POST['delx'];
	
	mysqli_query($con," delete from orders where id ='$delx' limit 1");
	echo'<script>	alert(" Record deleted fully ");	</script>';
	}
	
	else if (isset($_POST['updatbtn'])){
	
	$updat=$_POST['updatbtn'];
	$status =$_POST['status'];
	
	 $qr =" update orders  set status ='$status' where id ='$updat' limit 1";
	 mysqli_query($con,$qr);

echo'<script>
	alert(" Update has been sucessful  ");
	 
	</script>';
	
	 
 
 
	} else if( isset($_POST['updata'])){

$updatau =$_POST['updata'];
$inameu =$_POST['iname'];
$weightu =$_POST['weight'];
$bfromu =$_POST['bfrom'];
$btou =$_POST['bto'];
 
$dateu =$_POST['date'];



$qr ="update orders set iname='$inameu',weight='$weightu',bfrom='$bfromu',bto='$btou',date='$dateu' where id='$updatau' limit 1 ";


 mysqli_query($con,$qr) or die(" Oooops !!! update failed , Try again".mysqli_error($con));
	
echo'<script>
	alert(" Update has been sucessful  ");
	 
	</script>';
	
	 
}
	
	
?>



<div class="cent">



 
  
  
  
  
  
  
  <table style="width:95%; margin-left:1%; float:left; background:rgba(188,244,247,1.00)">
  <tr><td align="center" colspan="9"> <h2> Search Customers  orders  so far</h2></td></tr>
  
  <tr>
  
  <td colspan="9" style="color:rgba(17,67,154,1.00); font-size:1.5em;">
  <form method="post" action="search.php" enctype="multipart/form-data"  >
  item name : <input name="in" /> &nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" name="search"> Search</button>
  </form>
  </td>
  </tr>
  
  <tr>
  <td></td>
  <td> item</td>
  <td> weight </td>
  <td> location</td>
  <td> destination</td>
  <td> date</td>
  <td> status</td>
  
  </tr>
  
  <?php 
  
  
  $c=0;
  if(isset($_POST['search'])){
	  $inx = $_POST['in'];
	  
	  $qr =" select * from orders  where iname like '%$inx%'  order by id desc";
	  
	  }else{
  
  $qr =" select * from orders   order by id desc";
	  }
$qrc =mysqli_query($con,$qr);

 while($qrx=mysqli_fetch_assoc($qrc)){ 
   ?>
   
   
     <tr>
  <td class="rec" style="width:20px;"><?php echo ++$c; ?></td>
  <td class="rec"> <?php echo $qrx['iname']; ?></td>
  <td class="rec"> <?php echo $qrx['weight']; ?></td>
  <td class="rec"> <?php echo $qrx['bfrom']; ?></td>
  <td class="rec"> <?php echo $qrx['bto']; ?></td>
  <td class="rec"> <?php echo $qrx['date']; ?></td>
  <form method="post" action="search.php" enctype="multipart/form-data" onSubmit='return confirm("do you want to Update <?php echo $qrx['iname']; ?>") '>
  <td class="rec"><select name="status" ><option><?php echo $qrx['status']; ?></option>
  <option> Delivered</option><option> Not Delivered Yet</option></select></td>
  <td class="rec">
  
  <button name="updatbtn" value="<?php echo $qrx['id']; ?>" >Update</button></td> </form>
  
  <td class="rec">
  <form method="post" action="adhome.php" enctype="multipart/form-data" onSubmit='return confirm("do you want to delete") '>
  <button style="background:rgba(243,176,161,0.9)" value="<?php echo $qrx['id']; ?>" name="delx" >Delete</button></form></td>
  
  </tr>
   
   
  
  <?php } ?>
  </table>

</div>

</body>