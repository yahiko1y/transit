<?php session_start(); 
 ?>
<style>
.cent{ width:60%; margin-left:20%; margin-top:20px; background: rgba(243,190,138,1.00); color:rgba(32,12,116,1.00) ; font-size:1.5em;
border-radius: 20px; padding:20px; align-content:center;  }

input,td,button{ font-size:1.3em;}
td,button{ width:50%;}
 
</style>
<body>

<?php 

require("dbcon.php");
if( isset($_POST['login'])){


 
$username = trim($_POST['username']);
$password =trim($_POST['password']);


$qr =" select * from  admin where username='$username'and password='$password' limit 1";


 $qrx=mysqli_query($con,$qr) ; //or die(" <a href='login.php'> Sorry  Invalid username or password !! try again to regester</a>");
 
 if(mysqli_num_rows($qrx) <1){
	 
	 echo'<script>	alert(" Sorry  Invalid username or password !! try again");	</script>';
	 }
	 else{
	 
	 $rw =mysqli_fetch_assoc($qrx);
	 
	$_SESSION['adnames']= $rw['fulnames'];
	$_SESSION['adminid']= $rw['id'];
	$_SESSION['password']= $rw['password'];
 
	 
echo'<script>
	alert(" Welcome Dear '.$rw['fulnames'].'");
	window.location="adhome.php";
	 
	</script>';
	
	 }
}

?>



<div class="cent">
 
 <form method="post" action="admlogin.php" enctype="multipart/form-data">
 <table>
 <tr><td colspan="2" align="center"> Welcome Dear  Adiministrator  !! Login below &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php"> << Back</a></td></tr>
  
 <tr>
   <td align="right">username</td><td><input  name="username" /></td>
 </tr>
 
 <tr>
   <td align="right">Password</td><td><input type="password" name="password" /></td>
 </tr>
 
 
 
 <tr>
   <td></td><td><br><br> <button type="submit" name="login"> Login</button></td>
 </tr>
 
 
 
 </table>
  </form>

</div>

</body>